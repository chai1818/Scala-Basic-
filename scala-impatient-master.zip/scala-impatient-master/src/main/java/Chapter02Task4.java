
public class Chapter02Task4 {

    public static void javaForLoop() {
        for (int i = 10; i >= 0; i--) {
            // use scala output to be able to redirect the output and test the results
            scala.Console.println(i);
            //System.out.println(i);
        }
    }
}
