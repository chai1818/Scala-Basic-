
public class Chapter15Task4 {

    public static int scalaSum(final int... args) {
        return Chapter15.sum(args);
    }
}
